#할인행사를 하고 있다. 물건값이 2000원일떄, 15% 할인된 가격을 구하시오.
price = 2000
discounted =(price -(price*0.15))
print("{}원". format(discounted))