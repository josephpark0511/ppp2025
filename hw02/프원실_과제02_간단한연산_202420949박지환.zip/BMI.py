# 키와 몸무게가 임의로 주어졌을 떄 BMI를 구하시오
weight =60
height = 170
BMI = weight/(height*height)
print("{}". format(BMI))

