# 섭씨를 화씨로 변환하는 프로그램을 작성하라.
temp_c =int(input("온도를 입력하시오=>"))
temp_f =(temp_c *9/5) +32
print( "{}C => {}F". format(temp_c,temp_f))

temp_c = int(input("온도를 입력하시오=>"))
temp_f =(temp_c *9/5) +32
print( "{}C => {}F". format(temp_c,temp_f))