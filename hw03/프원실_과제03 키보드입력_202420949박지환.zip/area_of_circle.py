import math

r =int(input("반지름을 입력하시오"))
pi = int(math.pi)
area = r*r*pi
print("반지름이 {}인 원의 면적은 {}입니다". format(r, area))



