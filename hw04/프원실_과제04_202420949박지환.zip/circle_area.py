import math
r =float(input("반지름을 입력하시오"))
pi = float(math.pi)
area = r*r*pi
circumference = 2*r*pi
print("원의 둘레는 {:.1f}입니다".format(circumference))
print("원의 면적은 {:.2f}입니다".format(area))






