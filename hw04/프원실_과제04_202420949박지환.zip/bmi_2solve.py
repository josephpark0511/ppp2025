#03의 BMI 계산결과에 따라 아래 텍스트를 참고하여, 비만 정도를 표시하시오.
height = float(input("키가 얼마인가요?=>"))
weight = float(input("몸무게는 얼마인가요?=>"))
height_m =height /100
BMI = weight/(height_m*height_m)
if (BMI>=23) and (BMI<=24.9):
    print("당신은 전 단계 비만 입니다")
elif (BMI>=25) and (BMI <=29.9):
    print("당신은 1단계 비만 입니다")
elif (BMI>=30) and (BMI<=34.9):
    print("당신은 2단계 비만 입니다.")
else:
    print(("당신은 3단계 비만 입니다"))

    #△23~24.9kg/㎡를 비만 전단계
# △25~29.9kg/㎡를 1단계 비만 △30~34.9kg/㎡를
# 2단계 비만
# △35kg/㎡이상을 3단계 비만으로 정의했다.”
